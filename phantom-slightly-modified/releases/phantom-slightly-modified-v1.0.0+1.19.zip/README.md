# Phantom Slightly Modified
For those who want a lightweight phantom modification that attempts to stay true to the original intent of integrating vanilla mechanics into the origin whilst also giving the origin a little more counterplay involving the sun and combat.

### Changelog
- Resets into phantomised form upon death.
- Introduced new power - Phasethrough Stomach. You are unable to eat while phantomised.
- If inside a block while hunger is less or equal to 3 shanks, you will slowly take damage (1 damage every 120 ticks/6 seconds) as opposed to being booted out of phantomised mode. The player will be booted out as soon as they leave from inside blocks.

### Dependencies
*None.*